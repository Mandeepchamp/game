package bean;

import java.util.Arrays;

public class Tansaction {
   double  deposit;
   double  withdraw;
   double  totalBalance;
public Tansaction(double deposit, double withdraw, double totalBalance) {
	super();
	
	this.withdraw = withdraw;
	this.totalBalance = totalBalance;
}

public Tansaction(double balance) {
	super();
	this.totalBalance = balance;
}
public Tansaction(double dAm, double balance) {
	super();
	this.deposit = dAm;
	this.totalBalance = balance;
}

public double getDeposit() {
	return deposit;
}
public void setDeposit(double deposit) {
	this.deposit = deposit;
}
public double getWithdraw() {
	return withdraw;
}
public void setWithdraw(double withdraw) {
	this.withdraw = withdraw;
}
@Override
public String toString() {
	return "Tansaction [deposit=" + deposit + ", withdraw=" + withdraw + ", totalBalance=" + totalBalance + "]";
}
public double getTotalBalance() {
	return totalBalance;
}
public void setTotalBalance(double totalBalance) {
	this.totalBalance = totalBalance;
}

   
}
