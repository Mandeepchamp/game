package bean;

public class Customer {
    
	private String custName;
    private String custAddress;
    private long custContact;
    private String custMail;
	
	
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public long getCustContact() {
		return custContact;
	}
	public void setCustContact(long custContact) {
		this.custContact = custContact;
	}
	public String getCustMail() {
		return custMail;
	}
	public void setCustMail(String custMail) {
		this.custMail = custMail;
	}
	public Customer(String custName, String custAddress, long custContact, String custMail) {
		super();
		this.custName = custName;
		this.custAddress = custAddress;
		this.custContact = custContact;
		this.custMail = custMail;
	}
	public String toString() {
		return "Customer [Customer Name = " + custName + " , Customer Address = " + custAddress + " , Customer Contact = " + custContact
				+ ", Customer Mail = " + custMail + "]";
	}
   
}
