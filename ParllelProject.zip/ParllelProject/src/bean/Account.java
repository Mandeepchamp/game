package bean;

public class Account {
	static int i= 0;
      long accountNo=190005471L;
     String bankName="HDFC";
     double balance=0.0;
     
     Customer c;
     
     Account(){
    	
    	
    }
     public Account(Customer c) {
    	 super();
    	 this.accountNo = accountNo+i;
    	 Account(accountNo,bankName,balance,c);
    	 i++;
 	}
     private void Account(long accountNo, String bankName, double balance, Customer c) {
 		this.accountNo = accountNo;
 		this.bankName = bankName;
 		this.balance = balance;
 		this.c=c;
 		
 	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Customer getC() {
		return c;
	}
	public void setC(Customer c) {
		this.c = c;
	}
	
	@Override
	public String toString() {
		return "Account [ Account No = "+accountNo+ ", Balance = " + balance + ", Customer Details = " + c + "]";
	}
	
	
	
     
}
